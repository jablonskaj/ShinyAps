#ifndef SOURCETOOLS_R_R_HEADERS_H
#define SOURCETOOLS_R_R_HEADERS_H

#define R_NO_REMAP
#include <R.h>
#include <Rinternals.h>

#endif /* SOURCETOOLS_R_R_HEADERS_H */
